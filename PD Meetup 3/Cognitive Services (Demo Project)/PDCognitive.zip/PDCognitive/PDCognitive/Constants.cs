﻿namespace PDCognitive
{
	public static class Constants
	{
		// Put your API keys here :D
		// You can get yours for free at https://www.microsoft.com/cognitive-services

		public static readonly string EmotionKey = "";
		public static readonly string FaceKey = "";
		public static readonly string VisionKey = "";
	}
}
